<?php

namespace App\Http\Controllers;

use App\Models\School;
use App\Models\User;

class SchoolsController extends Controller
{
    public function index()
    {
        $data = School::all();

        return response()->json($data);
    }

    public function show($id)
    {
        $data = School::with('department', 'department.region')->findOrFail($id);

        $supervisor = User::where('role', 'supervisor')->where('school_id', $id)->select('firstname', 'lastname', 'surname')->first();
        $expert = User::where('role', 'expert')->where('school_id', $id)->select('firstname', 'lastname', 'surname')->first();

        return response()->json([
            'school' => $data,
            'supervisor' => $supervisor,
            'expert' => $expert,
        ]);

    }
}
