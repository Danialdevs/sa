<?php

namespace App\Http\Controllers;

use App\Models\Region;

class RegionsController extends Controller
{
    public function index()
    {
        $data = Region::all();

        return response()->json($data);
    }

    public function show($id)
    {
        $data = Region::with('departments')->findOrFail($id);

        return response()->json($data);
    }
}
