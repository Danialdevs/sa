<?php

namespace App\Http\Controllers;

use App\Models\Department;

class DepartmentsController extends Controller
{
    public function index()
    {
        $data = Department::all();

        return response()->json($data);
    }

    public function show($id)
    {
        $data = Department::with('region')->findOrFail($id);

        return response()->json($data);

    }
}
