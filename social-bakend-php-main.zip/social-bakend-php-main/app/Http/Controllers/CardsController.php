<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddCardRequest;
use App\Http\Requests\ParentRequest;
use App\Models\Card_category;
use App\Models\Card_category_card;
use App\Models\Card_parents;
use App\Models\Cards;
use App\Models\Element;
use App\Models\Element_value;
use App\Models\ParentCard;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class CardsController extends Controller
{
    public function school(){
        // Проверяем, авторизован ли пользователь
        if (!\Auth::check()) {
            return response()->json(['error' => 'Пользователь не авторизован'], 401);
        }

        $user = \Auth::user();

        $cards = Cards::where('school_id', $user->school_id)->get();

        if ($cards->isEmpty()) {
            return response()->json(['error' => 'Карты не найдены для данной школы'], 404);
        }
        return response()->json($cards);
    }

    public function show($id)
    {
        $data = Cards::with('card_categories.category', 'school', 'values.element', 'card_parents.parent', 'files')->findOrFail($id);

        return response()->json($data);
    }
    public function addCard(Request $request){
        $data = $request->all();
        $data['school_id'] = \Auth::user()->school_id;
        $data['avatar'] = 'https://upload.wikimedia.org/wikipedia/commons/5/59/User-avatar.svg';

        Cards::create($data);

        return response()->json('true');
    }


    public function showCategoryElements($id)
    {
        $mainElements = Element::whereHas('element_categories', function ($query) use ($id) {
            $query->where('card_category_id', $id);
        })->get();


        return response()->json($mainElements);

    }

    public function showCardElementValuesByCategory($card_id, $category_id)
    {
        $data = Element_value::where('card_id', $card_id)
            ->whereHas('element', function (Builder $query) use ($category_id) {
                $query->where('card_category_id', $category_id);
            })
            ->get();

        return response()->json($data);
    }

    public function bySchool($id)
    {
        $totalUsersCount = Card_category_card::whereHas('card', function ($query) use ($id) {
            $query->where('school_id', $id);
        })
            ->count();

        $categories = Card_category::all();

        $categoryData = [];

        foreach ($categories as $category) {
            $usersCount = Card_category_card::where('card_category_id', $category->id)
                ->whereHas('card', function ($query) use ($id) {
                    $query->where('school_id', $id);
                })
                ->count();

            $percentage = ($totalUsersCount > 0) ? ($usersCount / $totalUsersCount) * 100 : 0;

            $categoryData[] = [
                'id' => $category->id,
                'name' => $category->name,
                'users_count' => $usersCount,
                'percentage' => round($percentage),
            ];
        }

        $cards_count = Cards::where('school_id', $id)->count();

        return response()->json(
            [
                'categoryies' => $categoryData,
                'cards_count' => $cards_count,
            ]
        );
    }

    public function categories(){
        if (\Auth::user() && in_array(\Auth::user()->role, ['supervisor', 'expert'])) {
            $school_id = \Auth::user()->school_id;
            $totalUsersCount = Card_category_card::whereHas('card', function ($query) use ($school_id) {
                $query->where('school_id', $school_id);
            })
                ->count();

            $categories = Card_category::all();

            $categoryData = [];

            foreach ($categories as $category) {
                $usersCount = Card_category_card::where('card_category_id', $category->id)
                    ->whereHas('card', function ($query) use ($school_id) {
                        $query->where('school_id', $school_id);
                    })
                    ->count();

                $percentage = ($totalUsersCount > 0) ? ($usersCount / $totalUsersCount) * 100 : 0;

                $categoryData[] = [
                    'id' => $category->id,
                    'name' => $category->name,
                    'users_count' => $usersCount,
                    'percentage' => round($percentage),
                ];
            }

            $cards_count = Cards::where('school_id', $school_id)->count();

            return response()->json(
                [
                    'categoryies' => $categoryData,
                    'cards_count' => $cards_count,
                ]
            );
        }elseif(\Auth::user()->role == 'admin'){
            $deparment_id = \Auth::user()->department_id;

            $totalUsersCount = Card_category_card::whereHas('card.school', function ($query) use ($deparment_id) {
                $query->where('department_id', $deparment_id);
            })
                ->count();

            $categories = Card_category::all();

            $categoryData = [];

            foreach ($categories as $category) {
                $usersCount = Card_category_card::where('card_category_id', $category->id)
                    ->whereHas('card.school', function ($query) use ($deparment_id) {
                        $query->where('department_id', $deparment_id);
                    })
                    ->count();

                $percentage = ($totalUsersCount > 0) ? ($usersCount / $totalUsersCount) * 100 : 0;

                $categoryData[] = [
                    'id' => $category->id,
                    'name' => $category->name,
                    'users_count' => $usersCount,
                    'percentage' => round($percentage),
                ];
            }

            $cards_count = Cards::whereHas('school', function ($query) use ($deparment_id) {
                $query->where('department_id', $deparment_id);
            })->count();

            return response()->json(
                [
                    'categoryies' => $categoryData,
                    'cards_count' => $cards_count,
                ]
            );
        }
    }
    public function byCategory($category_id)
    {

        $cardsWithValues = Cards::whereHas('values.element.element_categories', function ($query) use ($category_id) {
            $query->where('card_category_id', $category_id);
        })->with(['values' => function ($query) use ($category_id) {
            $query->whereHas('element', function ($query) use ($category_id) {
                $query->whereHas('element_categories', function ($query) use ($category_id) {
                    $query->where('card_category_id', $category_id);
                });
            });
        }])->get();




        return response()->json([
            'data' => $cardsWithValues,
            'count' => $cardsWithValues->count(),
        ]);
    }

    public function storeParent(ParentRequest $request, $id){
        $parent = \DB::table('parents')->insertGetId($request->all());

        Card_parents::create([
            'card_id' => $id,
            'parent_id' => $parent
        ]);

        return response()->json($parent);
    }

    public function deletParent($id){
        \DB::table('parents')->where('id', $id)->delete();
    }

    public function addCategoryCard($category_id, $card_id){
        $existingRecord = Card_category_card::where('card_id', $card_id)
            ->where('card_category_id', $category_id)
            ->first();

        if ($existingRecord) {
            return response()->json(['message' => 'Эта категория уже добавлена к карте'], 200);
        }

        $category = Card_category_card::create([
            'card_id' => $card_id,
            'card_category_id' => $category_id,
        ]);
        $elementCategories = $category->category->element_categories;

        foreach ($elementCategories as $elementCategory) {
            $existingElementValue = Element_value::where('element_id', $elementCategory->element_id)
                ->where('card_id', $card_id)
                ->first();

            if (!$existingElementValue) {
                Element_value::create([
                    'element_id' => $elementCategory->element_id,
                    'card_id' => $card_id,
                    'value' => '',
                ]);
            }
        }

        return response()->json(['message' => 'Категория успешно добавлена к карте'], 201);
    }

    public function update(Request $request,$id){
        $data = $request->all();

        $card = Cards::findOrFail($id);
        $card->update([
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'surname' => $data['surname'],
            'school_id' => $data['school_id'],
            'inn' => $data['inn'],
            'avatar' => $data['avatar'],
        ]);



        if (isset($data['values'])) {
            foreach ($data['values'] as $valueData) {
                $value = Element_value::findOrFail($valueData['id']);
                $value->update([
                    'value' => $valueData['value'],

                ]);
            }
        }


        return response()->json(['message' => 'Данные успешно обновлены'], 200);
    }


}
