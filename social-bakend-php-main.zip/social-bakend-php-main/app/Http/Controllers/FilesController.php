<?php

namespace App\Http\Controllers;

use App\Models\Cards;
use App\Models\Files;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FilesController extends Controller
{
    public function addFileToCard(Request $request, $card_id)
    {
        $Card = Cards::findOrFail($card_id);

        if ($request->hasFile('file')) {
            $file = $request->file('file');

            // Генерируем уникальное имя файла
            $fileName = time() . '_' . $file->getClientOriginalName();

            // Сохраняем файл в папку на сервере (например, public/uploads)
            $file->move(public_path('uploads'), $fileName);

            // Формируем путь к файлу
            $path = 'uploads/' . $fileName;

            // Создаем запись о файле в базе данных
            $fileRecord = Files::create([
                'title' => $request->title,
                'card_id' => $Card->id,
                'file_path' => $path
            ]);

            // Возвращаем ответ с записью о карте, или можете вернуть информацию о добавленном файле
            return response()->json($Card);
        } else {
            // Если файл не был отправлен, возвращаем ошибку
            return response()->json(['error' => 'No file uploaded'], 400);
        }
    }

}
