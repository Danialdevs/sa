<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ParentRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'bord' => ['required', 'date'],
            'edu' => ['required', 'string'],
            'work_place' => ['required', 'string'],
            'work_role' => ['required', 'string'],
            'phone' => ['required', 'string'],
            'type' => ['required', 'in:mom,dad'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
