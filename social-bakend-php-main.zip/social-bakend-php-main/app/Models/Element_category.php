<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Element_category extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'element_id',
        'card_category_id',
    ];

}
