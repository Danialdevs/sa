<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Card_category extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'name',
    ];

    public function element_categories(): HasMany
    {
        return $this->hasMany(Element_category::class, 'card_category_id');
    }
}
