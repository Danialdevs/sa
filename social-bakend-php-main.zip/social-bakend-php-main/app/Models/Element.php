<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Element extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'title',
        'titleInElement',
        'type',
        'content',
    ];

    public function element_categories(): HasMany
    {
        return $this->hasMany(Element_category::class, 'element_id');
    }

}
