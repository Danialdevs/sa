<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Cards extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'firstname',
        'lastname',
        'surname',
        'school_id',
        'grade',
        'age',
        'inn',
        'avatar'
    ];

    public function card_categories()
    {
        return $this->hasMany(Card_category_card::class, 'card_id');
    }

    public function school()
    {
        return $this->belongsTo(School::class);
    }

    public function values()
    {
        return $this->hasMany(Element_value::class, 'card_id');
    }

    public function card_parents(): HasMany
    {
        return $this->hasMany(Card_parents::class, 'card_id');

    }

    public function files(): HasMany
    {
        return $this->hasMany(Files::class, 'card_id');
    }
}
