<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Card_parents extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'card_id',
        'parent_id',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(ParentCard::class);
    }
}
