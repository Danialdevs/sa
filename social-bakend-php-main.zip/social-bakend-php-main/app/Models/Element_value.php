<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Element_value extends Model
{
    protected $fillable = [
        'element_id',
        'value',
        'card_id'

    ];

    public function element(): BelongsTo
    {
        return $this->belongsTo(Element::class, 'element_id');
    }

    public function card(): BelongsTo
    {
        return $this->belongsTo(Cards::class, 'card_id');
    }

    public function categories(): HasMany
    {
        return $this->hasMany(Card_category::class);
    }

}
