<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Card_category_card extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'card_id',
        'card_category_id',
    ];

    public function category()
    {
        return $this->belongsTo(Card_category::class, 'card_category_id');
    }

    public function card()
    {
        return $this->belongsTo(Cards::class);
    }



}
