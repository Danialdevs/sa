<?php

namespace App\Admin\Controllers;

use App\Models\Department;
use App\Models\School;
use App\Models\User;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class UserController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'User';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new User());

        $grid->column('id', __('Id'));
        $grid->column('inn', __('Inn'));
        $grid->column('email', __('Email'));
        $grid->column('email_verified_at', __('Email verified at'));
        $grid->column('password', __('Password'));
        $grid->column('bornDate', __('BornDate'));
        $grid->column('firstname', __('Firstname'));
        $grid->column('lastname', __('Lastname'));
        $grid->column('sex', __('Sex'));
        $grid->column('surname', __('Surname'));
        $grid->column('role', __('Role'));
        $grid->column('school_id', __('School id'));
        $grid->column('department_id', __('Department id'));
        $grid->column('remember_token', __('Remember token'));
        $grid->column('created_at', __('Created at'));
        $grid->column('updated_at', __('Updated at'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(User::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('inn', __('Inn'));
        $show->field('email', __('Email'));
        $show->field('email_verified_at', __('Email verified at'));
        $show->field('password', __('Password'));
        $show->field('bornDate', __('BornDate'));
        $show->field('firstname', __('Firstname'));
        $show->field('lastname', __('Lastname'));
        $show->field('sex', __('Sex'));
        $show->field('surname', __('Surname'));
        $show->field('role', __('Role'));
        $show->field('school_id', __('School id'));
        $show->field('department_id', __('Department id'));
        $show->field('remember_token', __('Remember token'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new User());

        $form->number('inn', __('Inn'));
        $form->email('email', __('Email'));
        $form->datetime('email_verified_at', __('Email verified at'))->default(date('Y-m-d H:i:s'));
        $form->password('password', __('Password'));
        $form->date('bornDate', __('BornDate'))->default(date('Y-m-d'));
        $form->text('firstname', __('Firstname'));
        $form->text('lastname', __('Lastname'));
        $form->number('sex', __('Sex'));
        $form->text('surname', __('Surname'));
        $form->select('role', __('Role'))->options([
            'admin' => 'Администратор',
            'teacher' => 'Учитель',

        ]);
        $form->radio('school_id','школа')->options(School::all()->pluck('name','id'));
        $form->radio('department_id','школа')->options(Department::all()->pluck('name','id'));
        $form->text('remember_token', __('Remember token'));

        return $form;
    }
}
