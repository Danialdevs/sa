<?php

use Illuminate\Routing\Router;
use App\Admin\Controllers\UserController;
use App\Admin\Controllers\DepartmentController;
use App\Admin\Controllers\RegionController;
use App\Admin\Controllers\SchoolController;
use App\Admin\Controllers\ElementsController;
use App\Admin\Controllers\CategoriesController;

Admin::routes();

Route::group([
    'prefix'        => config('admin.route.prefix'),
    'namespace'     => config('admin.route.namespace'),
    'middleware'    => config('admin.route.middleware'),
    'as'            => config('admin.route.prefix') . '.',
], function (Router $router) {

    $router->get('/', 'HomeController@index')->name('home');
    $router->resource('users', UserController::class);
    $router->resource('department', DepartmentController::class);
    $router->resource('regions', RegionController::class);
    $router->resource('schools', SchoolController::class);
    $router->resource('categories', CategoriesController::class);
    $router->resource('elements', ElementsController::class);

});
