<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CardsController;
use App\Http\Controllers\DepartmentsController;
use App\Http\Controllers\RegionsController;
use App\Http\Controllers\SchoolsController;
use App\Http\Controllers\FilesController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::group(['prefix' => 'auth'], function () {
    Route::post('login', [AuthController::class, 'login']);
    Route::get('/user', [AuthController::class, 'me']);
    Route::post('refresh', [AuthController::class, 'refresh']);
    Route::post('logout', [AuthController::class, 'logout']);
});

Route::group(['prefix' => 'regions'], function () {
    Route::get('/', [RegionsController::class, 'index']);
    Route::get('/{id}', [RegionsController::class, 'show']);
});

Route::group(['prefix' => 'departments'], function () {
    Route::get('/', [DepartmentsController::class, 'index']);
    Route::get('/{id}', [DepartmentsController::class, 'show']);
});
Route::group(['prefix' => 'schools'], function () {
    Route::get('/', [SchoolsController::class, 'index']);
    Route::get('/{id}', [SchoolsController::class, 'show']);
});

Route::group(['prefix' => 'cards'], function () {
    Route::post('/add', [CardsController::class, 'addCard']);
    Route::get('/{id}', [CardsController::class, 'show']);
    Route::post('/parent/{id}', [CardsController::class, 'storeParent']);
    Route::delete('/parent/{id}', [CardsController::class, 'deletParent']);
    Route::get('/byCategory/{category_id}', [CardsController::class, 'byCategory']);
    Route::post('/{id}', [CardsController::class, 'update']);
    Route::post('/add/file/{card_id}', [FilesController::class, 'addFileToCard']);
    Route::get('/all', [CardsController::class, 'school']);
});
Route::group(['prefix' => 'categories'], function () {
    Route::get('/', [CardsController::class, 'categories']);

    Route::post('/add/{category_id}/{card_id}', [CardsController::class, 'addCategoryCard']);

    Route::get('/rows/{id}', [CardsController::class, 'showCategoryElements']);
    Route::get('/showCardElementValuesByCategory/{card_id}/{category_id}', [CardsController::class, 'showCardElementValuesByCategory']);
});
