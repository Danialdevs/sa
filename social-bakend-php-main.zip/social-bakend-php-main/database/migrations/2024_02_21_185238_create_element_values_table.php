<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('element_values', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('element_id')->unsigned();
            $table->bigInteger('card_id')->unsigned();
            $table->longText('value')->nullable();
            $table->timestamps();

            $table->foreign('element_id')->references('id')->on('elements');
            $table->foreign('card_id')->references('id')->on('cards');

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('element_values');
    }
};
