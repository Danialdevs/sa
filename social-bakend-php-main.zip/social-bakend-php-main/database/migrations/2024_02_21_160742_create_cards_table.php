<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cards', function (Blueprint $table) {
            $table->id();
            $table->string('firstname');
            $table->string('lastname');
            $table->string('surname');
            $table->bigInteger('school_id')->unsigned();
            $table->integer('inn');
            $table->string('avatar');

            $table->foreign('school_id')->references('id')->on('schools');

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cards');
    }
};
